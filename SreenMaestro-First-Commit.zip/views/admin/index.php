<?php
// /views/admin/index.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Creative City Media</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">

    
</head>

<body>

<div class="admin-content">

<h1>Manage Screens</h1>

<a href="screen_editor.php?id=new" class="admin-button" style="background-color: #28a745;">➕ Create New Screen</a>

<?php foreach ($groups as $groupName => $screensInGroup): ?>
    <h2><?php echo htmlspecialchars($groupName); ?></h2>

    <?php foreach ($screensInGroup as $screen): ?>
        <div class="screen-card">
            <div class="screen-header"><?php echo htmlspecialchars($screen['screen_name']); ?></div>
            <div class="screen-details">
                <strong>Group:</strong> <?php echo htmlspecialchars($screen['screen_group']); ?><br>
                <strong>Theme:</strong> <?php echo htmlspecialchars($screen['theme']); ?><br>
                <strong>Mode:</strong> <?php echo ucfirst(htmlspecialchars($screen['layout_mode'])); ?>
            </div>
            <div class="actions">
                <a href="screen_editor.php?id=<?php echo (int)$screen['id']; ?>" class="btn btn-edit">✏️ Edit</a>
                <a href="media_manager.php?id=<?php echo (int)$screen['id']; ?>" class="btn btn-media">🖼️ Media</a>
                <a href="content_editor.php?id=<?php echo (int)$screen['id']; ?>" class="btn btn-content"">📝 Content</a>
                <a href="generate_share_link.php?id=<?php echo (int)$screen['id']; ?>" class="btn btn-link" target="blank:">🔗 Link</a>
                <a href="delete_screen.php?id=<?php echo (int)$screen['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this screen?')">🗑️ Delete</a>
            </div>
        </div>
    <?php endforeach; ?>

<?php endforeach; ?>

</div>

</body>
</html>
