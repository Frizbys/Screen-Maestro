<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Screen Maestro</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <script defer src="../assets/js/navbar.js"></script>
</head>
<body>

<nav class="navbar">
    <div class="container">
        <div class="logo">
            <img src="../assets/branding/logo.png" alt="Screen Maestro Logo"> 
           
        </div>
        <div class="menu-toggle" id="mobile-menu">&#9776;</div>
        <ul class="nav-links" id="nav-links">
            <li><a href="admin.php" class="btn btn-primary">Dashboard</a></li>
            <li><a href="screen_editor.php?id=new" class="btn">Create Screen</a></li>
            <li><a href="logout.php" class="btn btn-danger">Logout</a></li>
        </ul>
    </div>
</nav>

<div class="admin-content">
    <!-- Your dynamic admin content will go here -->

</div> <!-- end admin-content -->

</body>
</html>
