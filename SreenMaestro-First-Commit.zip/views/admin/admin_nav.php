<?php
// /public/admin_nav.php

?>
<style>
.admin-nav {
    background: #333;
    color: #fff;
    padding: 10px;
    margin-bottom: 20px;
}
.admin-nav a {
    color: #fff;
    margin-right: 15px;
    text-decoration: none;
}
.admin-nav a:hover {
    text-decoration: underline;
}
</style>

<div class="admin-nav">
    <a href="admin.php">🏠 Dashboard</a>
    <a href="screen_editor.php?id=new">➕ Create New Screen</a>
    
    <a href="logout.php" style="float:right;">🚪 Logout</a>
</div>
