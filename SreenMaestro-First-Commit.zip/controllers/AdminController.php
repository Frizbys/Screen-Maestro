<?php
// /controllers/AdminController.php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Screen.php';

class AdminController
{
    private $screenModel;
    private $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
        $this->screenModel = new Screen($pdo);
    }

    public function getScreens()
    {
        return $this->screenModel->getAllScreens();
    }

    public function getScreensByGroup($group)
    {
        return $this->screenModel->getScreensByGroup($group);
    }

    public function getScreen($id)
    {
        return $this->screenModel->getScreenById($id);
    }

    public function createScreen($postData)
    {
        $this->screenModel->createScreen($this->sanitizeScreenData($postData));
    }

    public function updateScreen($id, $postData)
    {
        $this->screenModel->updateScreen($id, $this->sanitizeScreenData($postData));
    }

    public function deleteScreen($id)
    {
        $this->screenModel->deleteScreen($id);
    }

    // Corrected: fetch content from screen_content_blocks
    public function getScreenContentHtml($screen_id)
    {
        $stmt = $this->pdo->prepare("SELECT content_html FROM screen_content_blocks WHERE screen_id = ? ORDER BY block_order ASC, id ASC");
        $stmt->execute([$screen_id]);
        $blocks = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $output = '';
        foreach ($blocks as $block) {
            $output .= $block['content_html'];
        }
        return $output;
    }

    public function getContentBlocks($screen_id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM screen_content_blocks WHERE screen_id = ? ORDER BY block_order ASC, id ASC");
        $stmt->execute([$screen_id]);
        return $stmt->fetchAll();
    }

    public function addContentBlock($screen_id, $html_content, $block_order = 0)
    {
        $stmt = $this->pdo->prepare("INSERT INTO screen_content_blocks (screen_id, content_html, block_order) VALUES (?, ?, ?)");
        return $stmt->execute([$screen_id, $html_content, $block_order]);
    }

    public function updateContentBlock($block_id, $html_content)
    {
        $stmt = $this->pdo->prepare("UPDATE screen_content_blocks SET content_html = ? WHERE id = ?");
        return $stmt->execute([$html_content, $block_id]);
    }

    public function deleteContentBlock($block_id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM screen_content_blocks WHERE id = ?");
        return $stmt->execute([$block_id]);
    }

    public function addMediaToScreen($screenId, $filename, $fileType)
    {
        $stmt = $this->pdo->prepare("INSERT INTO signage_images (screen_id, image_filename, file_type) VALUES (?, ?, ?)");
        $stmt->execute([$screenId, $filename, $fileType]);
    }

    public function getMediaForScreen($screenId)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM signage_images WHERE screen_id = ?");
        $stmt->execute([$screenId]);
        return $stmt->fetchAll();
    }

    private function sanitizeScreenData($data)
    {
        return [
            'screen_number' => intval($data['screen_number']),
            'screen_name' => trim($data['screen_name']),
            'screen_group' => trim($data['screen_group']),
            'ticker_text' => trim($data['ticker_text']),
            'qr_link' => trim($data['qr_link']),
            'theme' => trim($data['theme']) ?: 'default',
            'ticker_speed' => trim($data['ticker_speed']) ?: 'medium',
            'ticker_direction' => trim($data['ticker_direction']) ?: 'left',
            'ticker_font_size' => trim($data['ticker_font_size']) ?: '16px',
            'ticker_color' => trim($data['ticker_color']) ?: '#FFFFFF',
            'ticker_bg_color' => trim($data['ticker_bg_color']) ?: '#000000',
            'ticker_enabled' => isset($data['ticker_enabled']) ? 1 : 0,
            'ticker_font' => trim($data['ticker_font']) ?: 'Arial',
            'rotation_interval' => intval($data['rotation_interval']) ?: 8,
            'layout_mode' => trim($data['layout_mode']) ?: 'media'
        ];
    }
}
?>
