<?php
// /public/view_screen_content.php
// $adminController, $screen, and $screen_id are already available

$contentHtml = $adminController->getScreenContentHtml($screen_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($screen['screen_name']); ?> - Content Screen</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="refresh" content="300"> <!-- Optional: auto-refresh every 5 minutes -->
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #000;
            color: #fff;
            overflow: hidden;
        }
        .content-wrapper {
            width: 100vw;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 2vw;
            box-sizing: border-box;
        }
        .content-wrapper * {
            max-width: 100%;
            word-break: break-word;
        }
        .content-wrapper img, .content-wrapper video {
            max-width: 100%;
            height: auto;
        }
    </style>
</head>
<body>

<div class="content-wrapper">
    <?php echo $contentHtml; ?>
</div>

</body>
</html>
