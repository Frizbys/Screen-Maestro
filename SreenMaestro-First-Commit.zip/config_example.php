<?php
/**
 * ScreenMaestro Configuration Sample
 * 
 * Copy this file to config.php
 * Then fill in your own database credentials.
 * 
 * Keep your config.php private and NEVER upload it publicly!
 */

// Database Settings
define('DB_HOST', 'your-database-host'); // e.g., localhost
define('DB_NAME', 'your-database-name'); // e.g., screenmaestro_db
define('DB_USER', 'your-database-username'); // e.g., root
define('DB_PASS', 'your-database-password'); // e.g., supersecretpassword

// Base Path Settings
define('BASE_PATH', realpath(__DIR__ . '/../')); // Automatically resolves project base directory

// (Optional) Other Settings
// define('APP_ENV', 'production'); // or 'development'

?>
